# Languages Directory

This directory contains language files for WordPress Plugin Directory Filters.

Currently, the plugin is available in English. Translation contributions are welcome.

To contribute translations:
1. Use the .pot file as a template
2. Create .po files for your language
3. Submit via the WordPress.org translation system once the plugin is approved

## Translation Status

- English (en_US): 100% (default)
- Other languages: Contributions welcome